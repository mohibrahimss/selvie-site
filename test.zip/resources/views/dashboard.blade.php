<x-app-layout>
    <script>
        window.location.href = "{{ route('mentor.dashboard') }}";
    </script>
</x-app-layout>
