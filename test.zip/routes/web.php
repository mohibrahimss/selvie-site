<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

// Public routes
Route::get('/', function () {
    return redirect()->route('dashboard');
})->name('welcome');

// Protected routes
Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    // Dashboard redirect based on role
    Route::get('/dashboard', function () {
        $user = auth()->user();

        if ($user->hasRole('super_admin')) {
            return redirect()->route('super-admin.dashboard');
        } elseif ($user->hasRole('group_admin')) {
            // Removed logout and redundant redirect.
            return redirect()->route('group-admin.dashboard');
        } elseif ($user->hasRole('mentor')) {
            return redirect()->route('mentor.dashboard');
        }
        Auth::guard(name: 'web')->logout();
        return redirect('/login');// no front end view yet for this specific senario so redirect to login page;
        // return view('welcome');
    })->name('dashboard');

    // Super Admin Routes
    Route::middleware(['auth', 'role:super_admin'])->prefix('super-admin')->group(function () {
        Route::get('/dashboard', function(){return 'testing..!';})->name('super-admin.dashboard');
        Route::get('/dashboard', App\Livewire\SuperAdmin\Dashboard::class)->name('super-admin.dashboard');
        
    });

    // Group Admin Routes
    Route::middleware(['role:group_admin'])->prefix('group-admin')->group(function () {
        // Auth::guard(name: 'web')->logout();
        // return redirect('/login');// no front end view;
        Route::get('/dashboard', App\Livewire\GroupAdmin\Dashboard::class)->name('group-admin.dashboard');
        
    });

    // Mentor Routes
    Route::middleware(['role:mentor'])->prefix('mentor')->group(function () {
        Route::get('/dashboard', App\Livewire\Mentor\Dashboard::class)->name('mentor.dashboard');
        // Note: Remove redundant "mentor" prefix from the URIs since the group already uses the "mentor" prefix.
        Route::get('/students', App\Livewire\Mentor\Students::class)->name('mentor.students');
        Route::get('/students/{studentId}', App\Livewire\Mentor\StudentProfile::class)->name('mentor.students.profile');
        Route::get('/calendar', App\Livewire\Mentor\Calendar::class)->name('mentor.calendar');
        Route::get('/tasks', App\Livewire\Mentor\Tasks::class)->name('mentor.tasks');
        Route::get('/training', App\Livewire\Mentor\TrainingCenter::class)->name('mentor.training');
        Route::get('/help', App\Livewire\Mentor\HelpSupport::class)->name('mentor.help');
    });

    // Participant Routes (currently commented out)
    // Route::get('/participant/dashboard', App\Livewire\Participant\Dashboard::class)->name('participant.dashboard');
});
